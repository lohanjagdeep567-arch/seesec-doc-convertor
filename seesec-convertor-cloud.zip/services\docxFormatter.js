const fs = require('fs');
const path = require('path');
const {
  Document,
  Packer,
  Paragraph,
  TextRun,
  Table,
  TableRow,
  TableCell,
  WidthType,
  AlignmentType,
  BorderStyle,
  Header,
  Footer,
  PageNumber,
  HeadingLevel,
  ImageRun,
  HorizontalPositionAlign,
  HorizontalPositionRelativeFrom,
  VerticalPositionAlign,
  VerticalPositionRelativeFrom
} = require('docx');

// Seesec Corporate Colors (User specified: Arial font, Black text, White/Transparent tables)
const COLORS = {
  NAVY_PRIMARY: '000000', // Pure Black
  NAVY_DARK: '000000',
  TEAL_ACCENT: '000000',
  TEXT_MAIN: '000000',    // Pure Black
  TEXT_MUTED: '000000',   // Pure Black
  BG_ALT_ROW: 'FFFFFF',   // White
  BORDER_GRAY: '000000',  // Black
  WHITE: 'FFFFFF'
};

function cleanText(str) {
  if (!str) return '';
  return String(str).replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x9F\uFFFD]/g, '');
}

function parseRichTextRuns(rawText, baseOptions = {}) {
  const text = cleanText(rawText);
  if (!text) return [new TextRun({ text: '', ...baseOptions })];

  const regex = /(\*\*([^*]+)\*\*|\*([^*]+)\*|`([^`]+)`)/g;
  let lastIndex = 0;
  const runs = [];
  let match;

  while ((match = regex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      runs.push(new TextRun({
        text: text.substring(lastIndex, match.index),
        ...baseOptions
      }));
    }
    if (match[2] !== undefined) {
      runs.push(new TextRun({
        text: match[2],
        bold: true,
        ...baseOptions
      }));
    } else if (match[3] !== undefined) {
      runs.push(new TextRun({
        text: match[3],
        italics: true,
        ...baseOptions
      }));
    } else if (match[4] !== undefined) {
      runs.push(new TextRun({
        text: match[4],
        font: 'Arial',
        bold: true,
        ...baseOptions
      }));
    }
    lastIndex = regex.lastIndex;
  }

  if (lastIndex < text.length) {
    runs.push(new TextRun({
      text: text.substring(lastIndex),
      ...baseOptions
    }));
  }

  return runs.length > 0 ? runs : [new TextRun({ text: text, ...baseOptions })];
}

function normalizeStr(s) {
  return String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
}

async function generateSeesecDocx(docData, outputPath) {
  const { title, subtitle, preparedBy, preparedFor, docVersion, date, sections } = docData;

  const headerLogoPath = path.resolve(__dirname, 'assets', 'seesec-header-logo.png');
  const watermarkPath = path.resolve(__dirname, 'assets', 'seesec-watermark.png');

  let headerLogoBuffer = fs.existsSync(headerLogoPath) ? fs.readFileSync(headerLogoPath) : null;
  let watermarkBuffer = fs.existsSync(watermarkPath) ? fs.readFileSync(watermarkPath) : null;

  // --- 1. COVER PAGE ELEMENTS ---
  const coverPageChildren = [];

  // Main Title (Line 1) - Centered in Upper-Center with breathing room
  coverPageChildren.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 800, after: 140 },
      children: [
        new TextRun({
          text: cleanText(title) || 'Official Document',
          bold: true,
          size: 46, // 23pt
          color: COLORS.NAVY_PRIMARY,
          font: 'Arial'
        })
      ]
    })
  );

  // Subtitle (Optional / User's Choice - only if NOT identical to title)
  if (subtitle && subtitle.trim() !== '' && normalizeStr(subtitle) !== normalizeStr(title)) {
    coverPageChildren.push(
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 0, after: 200 },
        children: [
          new TextRun({
            text: cleanText(subtitle),
            bold: true,
            size: 28, // 14pt
            color: '000000',
            font: 'Arial'
          })
        ]
      })
    );
  }



  // Centered Watermark Logo on Cover Page: Placed physically BETWEEN Title and Metadata Table (100% Identical Size to other pages: 300x300)
  const hasSubtitle = (subtitle && subtitle.trim() !== '' && normalizeStr(subtitle) !== normalizeStr(title));
  if (watermarkBuffer) {
    coverPageChildren.push(
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: hasSubtitle ? 400 : 600, after: 400 },
        children: [
          new ImageRun({
            data: watermarkBuffer,
            transformation: { width: 300, height: 300 }
          })
        ]
      })
    );
  } else {
    for (let i = 0; i < 6; i++) {
      coverPageChildren.push(
        new Paragraph({
          spacing: { before: 200, after: 200 },
          children: []
        })
      );
    }
  }

  // Metadata Table (Positioned DIRECTLY below Watermark Logo)
  const metaRows = [
    ['Prepared by', cleanText(preparedBy) || 'SEESEC Infotech Private Limited'],
    ['Prepared for', cleanText(preparedFor) || 'Corporate Client Review'],
    ...(docVersion && cleanText(docVersion) ? [['Document version', cleanText(docVersion)]] : []),
    ['Date', cleanText(date) || new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })]
  ];

  const metaTable = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: metaRows.map(([label, val]) => {
      return new TableRow({
        children: [
          new TableCell({
            width: { size: 28, type: WidthType.PERCENTAGE },
            margins: { top: 120, bottom: 120, left: 160, right: 160 },
            borders: {
              top: { style: BorderStyle.SINGLE, size: 4, color: COLORS.BORDER_GRAY },
              bottom: { style: BorderStyle.SINGLE, size: 4, color: COLORS.BORDER_GRAY },
              left: { style: BorderStyle.SINGLE, size: 4, color: COLORS.BORDER_GRAY },
              right: { style: BorderStyle.SINGLE, size: 4, color: COLORS.BORDER_GRAY }
            },
            children: [
              new Paragraph({
                children: [
                  new TextRun({
                    text: label,
                    bold: true,
                    size: 22, // 11pt
                    color: COLORS.NAVY_PRIMARY,
                    font: 'Arial'
                  })
                ]
              })
            ]
          }),
          new TableCell({
            width: { size: 72, type: WidthType.PERCENTAGE },
            margins: { top: 120, bottom: 120, left: 160, right: 160 },
            borders: {
              top: { style: BorderStyle.SINGLE, size: 4, color: COLORS.BORDER_GRAY },
              bottom: { style: BorderStyle.SINGLE, size: 4, color: COLORS.BORDER_GRAY },
              left: { style: BorderStyle.SINGLE, size: 4, color: COLORS.BORDER_GRAY },
              right: { style: BorderStyle.SINGLE, size: 4, color: COLORS.BORDER_GRAY }
            },
            children: [
              new Paragraph({
                children: [
                  new TextRun({
                    text: val,
                    size: 22, // 11pt
                    color: COLORS.TEXT_MAIN,
                    font: 'Arial'
                  })
                ]
              })
            ]
          })
        ]
      });
    })
  });

  coverPageChildren.push(metaTable);

  // --- 2. BODY PAGES ELEMENTS (Page 2 onwards) ---
  const bodyChildren = [];

  sections.forEach((sec) => {
    // Section Heading (H1) - Only render if a real heading exists (never render synthetic/empty headings)
    if (cleanText(sec.heading) && !sec.isSynthetic) {
      bodyChildren.push(
        new Paragraph({
          heading: HeadingLevel.HEADING_1,
          keepNext: true,
          keepLines: true,
          spacing: { before: 320, after: 120 },
          children: [
            new TextRun({
              text: cleanText(sec.heading),
              bold: true,
              size: 32, // 16pt
              color: COLORS.NAVY_PRIMARY,
              font: 'Arial'
            })
          ]
        })
      );
    }

    // Section Content
    sec.content.forEach((item) => {
      if (item.type === 'subheading') {
        bodyChildren.push(
          new Paragraph({
            heading: HeadingLevel.HEADING_2,
            keepNext: true,
            keepLines: true,
            spacing: { before: 200, after: 80 },
            children: [
              new TextRun({
                text: cleanText(item.text),
                bold: true,
                size: 26, // 13pt
                color: COLORS.NAVY_PRIMARY,
                font: 'Arial'
              })
            ]
          })
        );
      } else if (item.type === 'paragraph') {
        const isTocItem = sec.heading && /contents|table of contents/i.test(sec.heading);
        bodyChildren.push(
          new Paragraph({
            spacing: isTocItem ? { before: 20, after: 20 } : { before: 40, after: 120 },
            lineSpacing: isTocItem ? 240 : 276,
            children: parseRichTextRuns(item.text, {
              size: isTocItem ? 20 : 22,
              color: '000000',
              font: 'Arial'
            })
          })
        );
      } else if (item.type === 'bullet') {
        bodyChildren.push(
          new Paragraph({
            bullet: { level: 0 },
            spacing: { before: 30, after: 60 },
            children: parseRichTextRuns(item.text, {
              size: 22, // 11pt
              color: '000000',
              font: 'Arial'
            })
          })
        );
      } else if (item.type === 'numbered') {
        const isTocItem = sec.heading && /contents|table of contents/i.test(sec.heading);
        bodyChildren.push(
          new Paragraph({
            spacing: isTocItem ? { before: 20, after: 20 } : { before: 30, after: 60 },
            children: [
              new TextRun({
                text: `${item.num || '1'}. `,
                bold: true,
                color: '000000',
                size: isTocItem ? 20 : 22,
                font: 'Arial'
              }),
              ...parseRichTextRuns(item.text, {
                size: isTocItem ? 20 : 22,
                color: '000000',
                font: 'Arial'
              })
            ]
          })
        );
      } else if (item.type === 'callout') {
        const calloutChildren = [];
        if (item.title) {
          calloutChildren.push(
            new Paragraph({
              spacing: { before: 40, after: 60 },
              children: parseRichTextRuns(item.title, {
                bold: true,
                size: 22, // 11pt
                color: COLORS.NAVY_PRIMARY,
                font: 'Arial'
              })
            })
          );
        }
        calloutChildren.push(
          new Paragraph({
            spacing: { before: 20, after: 40 },
            children: parseRichTextRuns(item.text, {
              size: 21, // 10.5pt
              color: COLORS.TEXT_MAIN,
              font: 'Arial'
            })
          })
        );

        const calloutBox = new Table({
          width: { size: 100, type: WidthType.PERCENTAGE },
          rows: [
            new TableRow({
              cantSplit: true,
              children: [
                new TableCell({
                  margins: { top: 120, bottom: 120, left: 180, right: 140 },
                  borders: {
                    left: { style: BorderStyle.SINGLE, size: 24, color: '000000' },
                    top: { style: BorderStyle.SINGLE, size: 4, color: '000000' },
                    bottom: { style: BorderStyle.SINGLE, size: 4, color: '000000' },
                    right: { style: BorderStyle.SINGLE, size: 4, color: '000000' }
                  },
                  children: calloutChildren
                })
              ]
            })
          ]
        });

        bodyChildren.push(new Paragraph({ spacing: { before: 80, after: 40 } }));
        bodyChildren.push(calloutBox);
        bodyChildren.push(new Paragraph({ spacing: { before: 40, after: 80 } }));
      } else if (item.type === 'image') {
        try {
          const imgPath = item.filePath || (item.src && fs.existsSync(path.resolve(__dirname, '../public', item.src)) ? path.resolve(__dirname, '../public', item.src) : null);
          if (imgPath && fs.existsSync(imgPath)) {
            const imgData = fs.readFileSync(imgPath);
            const aspect = (item.width && item.height) ? (item.height / item.width) : 0.51;
            const targetWidth = 500;
            const targetHeight = Math.round(targetWidth * aspect);

            bodyChildren.push(
              new Paragraph({
                alignment: AlignmentType.CENTER,
                spacing: { before: 200, after: 80 },
                children: [
                  new ImageRun({
                    data: imgData,
                    transformation: { width: targetWidth, height: targetHeight }
                  })
                ]
              })
            );

            if (item.caption) {
              bodyChildren.push(
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  spacing: { before: 40, after: 180 },
                  children: [
                    new TextRun({
                      text: cleanText(item.caption),
                      size: 18, // 9pt
                      italics: true,
                      color: '000000',
                      font: 'Arial'
                    })
                  ]
                })
              );
            }
          }
        } catch (imgErr) {
          console.error('Error adding diagram image to DOCX:', imgErr);
        }
      } else if (item.type === 'table') {
        const tableRows = [];
        const numCols = Math.max(item.headers.length, 1);
        const colWidthPct = Math.floor(100 / numCols);

        // Header Row (Transparent / White with Black text & Black border)
        tableRows.push(
          new TableRow({
            tableHeader: true,
            cantSplit: true,
            children: item.headers.map((hText, colIdx) => {
              const cellWidth = (colIdx === numCols - 1) ? (100 - colWidthPct * (numCols - 1)) : colWidthPct;
              return new TableCell({
                width: { size: cellWidth, type: WidthType.PERCENTAGE },
                margins: { top: 120, bottom: 120, left: 140, right: 140 },
                borders: {
                  top: { style: BorderStyle.SINGLE, size: 6, color: '000000' },
                  bottom: { style: BorderStyle.SINGLE, size: 6, color: '000000' },
                  left: { style: BorderStyle.SINGLE, size: 4, color: '000000' },
                  right: { style: BorderStyle.SINGLE, size: 4, color: '000000' }
                },
                children: [
                  new Paragraph({
                    children: parseRichTextRuns(hText, {
                      bold: true,
                      size: 18, // 9pt
                      color: '000000',
                      font: 'Arial'
                    })
                  })
                ]
              });
            })
          })
        );

        // Data Rows (Transparent / White backgrounds)
        item.rows.forEach((rowCells) => {
          tableRows.push(
            new TableRow({
              cantSplit: true,
              children: rowCells.map((cellText, colIdx) => {
                const cellWidth = (colIdx === numCols - 1) ? (100 - colWidthPct * (numCols - 1)) : colWidthPct;
                return new TableCell({
                  width: { size: cellWidth, type: WidthType.PERCENTAGE },
                  margins: { top: 80, bottom: 80, left: 120, right: 120 },
                  borders: {
                    top: { style: BorderStyle.SINGLE, size: 4, color: '000000' },
                    bottom: { style: BorderStyle.SINGLE, size: 4, color: '000000' },
                    left: { style: BorderStyle.SINGLE, size: 4, color: '000000' },
                    right: { style: BorderStyle.SINGLE, size: 4, color: '000000' }
                  },
                  children: [
                    new Paragraph({
                      children: parseRichTextRuns(cellText, {
                        size: 18, // 9pt
                        color: '000000',
                        font: 'Arial'
                      })
                    })
                  ]
                });
              })
            })
          );
        });

        const dataTable = new Table({
          width: { size: 100, type: WidthType.PERCENTAGE },
          rows: tableRows
        });

        bodyChildren.push(new Paragraph({ spacing: { before: 100, after: 60 } }));
        bodyChildren.push(dataTable);
        bodyChildren.push(new Paragraph({ spacing: { before: 60, after: 120 } }));
      }
    });
  });

  // Header for Cover Page: Top-Right Seesec Logo only (Watermark is placed gracefully in body flow between Title and Table)
  const coverHeader = new Header({
    children: [
      new Paragraph({
        alignment: AlignmentType.RIGHT,
        spacing: { after: 200 },
        children: [
          ...(headerLogoBuffer
            ? [
                new ImageRun({
                  data: headerLogoBuffer,
                  transformation: { width: 52, height: 48 }
                })
              ]
            : [
                new TextRun({
                  text: 'SEESEC',
                  bold: true,
                  size: 18,
                  color: '000000',
                  font: 'Arial'
                })
              ])
        ]
      })
    ]
  });

  // Header for Body Pages (Background Watermark with 100% transparent PNG + Top-Right Logo on EVERY page)
  const bodyHeader = new Header({
    children: [
      new Paragraph({
        alignment: AlignmentType.RIGHT,
        spacing: { after: 200 },
        children: [
          ...(watermarkBuffer
            ? [
                new ImageRun({
                  data: watermarkBuffer,
                  transformation: { width: 300, height: 300 },
                  floating: {
                    horizontalPosition: {
                      relative: HorizontalPositionRelativeFrom.PAGE,
                      align: HorizontalPositionAlign.CENTER
                    },
                    verticalPosition: {
                      relative: VerticalPositionRelativeFrom.PAGE,
                      align: VerticalPositionAlign.CENTER
                    },
                    behindDocument: true
                  }
                })
              ]
            : []),
          ...(headerLogoBuffer
            ? [
                new ImageRun({
                  data: headerLogoBuffer,
                  transformation: { width: 52, height: 48 }
                })
              ]
            : [
                new TextRun({
                  text: 'SEESEC',
                  bold: true,
                  size: 18,
                  color: '000000',
                  font: 'Arial'
                })
              ])
        ]
      })
    ]
  });

  // Section 1: Cover Page Section
  // Section 2: Body Pages Section (Clean separation without empty blank page)
  const sectionsList = [
    {
      properties: {
        page: {
          margin: { top: 1000, bottom: 1000, left: 1440, right: 1440 }
        }
      },
      headers: {
        default: coverHeader
      },
      footers: {
        default: new Footer({
          children: [
            new Paragraph({
              alignment: AlignmentType.RIGHT,
              border: {
                top: { style: BorderStyle.SINGLE, size: 4, color: COLORS.BORDER_GRAY, space: 6 }
              },
              spacing: { before: 120 },
              children: [
                new TextRun({
                  text: 'Page ',
                  size: 16,
                  color: COLORS.TEXT_MUTED,
                  font: 'Arial'
                }),
                new TextRun({
                  children: [PageNumber.CURRENT],
                  size: 16,
                  color: COLORS.TEXT_MUTED,
                  font: 'Arial'
                }),
                new TextRun({
                  text: ' of ',
                  size: 16,
                  color: COLORS.TEXT_MUTED,
                  font: 'Arial'
                }),
                new TextRun({
                  children: [PageNumber.TOTAL_PAGES],
                  size: 16,
                  color: COLORS.TEXT_MUTED,
                  font: 'Arial'
                })
              ]
            })
          ]
        })
      },
      children: coverPageChildren
    },
    {
      properties: {
        page: {
          margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 }
        }
      },
      headers: {
        default: bodyHeader
      },
      footers: {
        default: new Footer({
          children: [
            new Paragraph({
              alignment: AlignmentType.RIGHT,
              border: {
                top: { style: BorderStyle.SINGLE, size: 4, color: COLORS.BORDER_GRAY, space: 6 }
              },
              spacing: { before: 120 },
              children: [
                new TextRun({
                  text: 'Page ',
                  size: 16,
                  color: COLORS.TEXT_MUTED,
                  font: 'Arial'
                }),
                new TextRun({
                  children: [PageNumber.CURRENT],
                  size: 16,
                  color: COLORS.TEXT_MUTED,
                  font: 'Arial'
                }),
                new TextRun({
                  text: ' of ',
                  size: 16,
                  color: COLORS.TEXT_MUTED,
                  font: 'Arial'
                }),
                new TextRun({
                  children: [PageNumber.TOTAL_PAGES],
                  size: 16,
                  color: COLORS.TEXT_MUTED,
                  font: 'Arial'
                })
              ]
            })
          ]
        })
      },
      children: bodyChildren
    }
  ];

  const doc = new Document({
    styles: {
      default: {
        document: {
          run: {
            font: 'Arial',
            color: '000000'
          }
        }
      }
    },
    sections: sectionsList
  });

  const buffer = await Packer.toBuffer(doc);
  const outDir = path.dirname(outputPath);
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(outputPath, buffer);
  return outputPath;
}

module.exports = { generateSeesecDocx };
