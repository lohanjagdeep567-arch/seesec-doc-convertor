const ExcelJS = require('exceljs');

const COLORS = {
  NAVY_PRIMARY: '000000',
  WHITE: 'FFFFFF',
  BG_ALT_ROW: 'FFFFFF',
  BORDER_GRAY: '000000',
  TEXT_MAIN: '000000',
  TEXT_MUTED: '000000'
};

async function generateSeesecExcel(docData, outputPath) {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'Seesec Infotech Private Limited';
  workbook.created = new Date();

  const { title, client, sections } = docData;

  // Ek worksheet add karte hain
  const worksheet = workbook.addWorksheet('Documentation Summary', {
    properties: { tabColor: { argb: '000000' } },
    views: [{ showGridLines: true, state: 'frozen', ySplit: 4 }]
  });

  // Row 1: Seesec Corporate Banner
  worksheet.mergeCells('A1:D1');
  const row1 = worksheet.getCell('A1');
  row1.value = 'SEESEC INFOTECH PRIVATE LIMITED — OFFICIAL DELIVERABLE';
  row1.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.WHITE } };
  row1.font = { name: 'Arial', size: 11, bold: true, color: { argb: COLORS.NAVY_PRIMARY } };
  row1.alignment = { vertical: 'middle', horizontal: 'left', indent: 1 };
  row1.border = {
    top: { style: 'thin', color: { argb: COLORS.BORDER_GRAY } },
    bottom: { style: 'thin', color: { argb: COLORS.BORDER_GRAY } },
    left: { style: 'thin', color: { argb: COLORS.BORDER_GRAY } },
    right: { style: 'thin', color: { argb: COLORS.BORDER_GRAY } }
  };
  worksheet.getRow(1).height = 28;

  // Row 2: Document Title & Client
  worksheet.mergeCells('A2:D2');
  const row2 = worksheet.getCell('A2');
  row2.value = `${title} | Client: ${client} | Date: ${new Date().toLocaleDateString('en-GB')}`;
  row2.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.WHITE } };
  row2.font = { name: 'Arial', size: 9.5, italic: true, color: { argb: COLORS.TEXT_MUTED } };
  row2.alignment = { vertical: 'middle', horizontal: 'left', indent: 1 };
  row2.border = {
    bottom: { style: 'thin', color: { argb: COLORS.BORDER_GRAY } },
    left: { style: 'thin', color: { argb: COLORS.BORDER_GRAY } },
    right: { style: 'thin', color: { argb: COLORS.BORDER_GRAY } }
  };
  worksheet.getRow(2).height = 20;

  // Row 3: Blank spacing row
  worksheet.getRow(3).height = 10;

  // Row 4: Column Headers
  const headerRow = worksheet.getRow(4);
  headerRow.height = 26;
  headerRow.values = ['Section #', 'Section Heading', 'Item Type', 'Content / Text Summary'];
  headerRow.eachCell((cell) => {
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.WHITE } };
    cell.font = { name: 'Arial', size: 10, bold: true, color: { argb: COLORS.NAVY_PRIMARY } };
    cell.alignment = { vertical: 'middle', horizontal: 'left' };
    cell.border = {
      top: { style: 'thin', color: { argb: COLORS.BORDER_GRAY } },
      bottom: { style: 'double', color: { argb: COLORS.BORDER_GRAY } },
      left: { style: 'thin', color: { argb: COLORS.BORDER_GRAY } },
      right: { style: 'thin', color: { argb: COLORS.BORDER_GRAY } }
    };
  });

  // Data Rows (Row 5+)
  let rowNum = 5;
  sections.forEach((sec, sIdx) => {
    sec.content.forEach((item) => {
      const dataRow = worksheet.getRow(rowNum);
      dataRow.height = 20;
      dataRow.values = [
        sIdx + 1,
        sec.heading,
        item.type.toUpperCase(),
        item.text || 'Table / Data Content'
      ];

      dataRow.eachCell((cell) => {
        cell.fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: COLORS.WHITE }
        };
        cell.font = { name: 'Arial', size: 9.5, color: { argb: COLORS.TEXT_MAIN } };
        cell.border = {
          top: { style: 'thin', color: { argb: COLORS.BORDER_GRAY } },
          bottom: { style: 'thin', color: { argb: COLORS.BORDER_GRAY } },
          left: { style: 'thin', color: { argb: COLORS.BORDER_GRAY } },
          right: { style: 'thin', color: { argb: COLORS.BORDER_GRAY } }
        };
      });
      rowNum++;
    });
  });

  // Auto-fit column widths
  worksheet.columns.forEach((col) => {
    let max = 15;
    col.eachCell({ includeEmpty: true }, (c, r) => {
      if (r >= 4) {
        const val = c.value ? String(c.value) : '';
        if (val.length > max) max = Math.min(val.length, 50);
      }
    });
    col.width = max + 4;
  });

  await workbook.xlsx.writeFile(outputPath);
  return outputPath;
}

module.exports = { generateSeesecExcel };
