"""Seesec Document Convertor - web dashboard (Flask).
Run:  python3 app.py   ->  http://localhost:5000
Portal integration points are marked  # PORTAL:  """
import json, os, re, subprocess, sys, time, uuid
from datetime import datetime, timedelta
from flask import Flask, abort, jsonify, request, send_file, send_from_directory

BASE = os.path.dirname(os.path.abspath(__file__))
JOBS = os.path.join(BASE, "jobs")
os.makedirs(JOBS, exist_ok=True)
RETENTION_HOURS = int(os.environ.get("SEESEC_RETENTION_HOURS", "24"))
ALLOWED = {".docx", ".xlsx"}

app = Flask(__name__, static_folder=os.path.join(BASE, "static"), static_url_path="/static")
app.config["MAX_CONTENT_LENGTH"] = 25 * 1024 * 1024


def current_user():
    # PORTAL: replace with the Seesec Portal's session / SSO check.
    # Return the logged-in user's id/email, or abort(401) when not logged in.
    return "internal-user"


def job_dir(job_id, create=False):
    if not re.fullmatch(r"[0-9a-f]{32}", job_id):
        abort(404)
    d = os.path.join(JOBS, job_id)
    if create:
        os.makedirs(d)
    elif not os.path.isdir(d):
        abort(404)
    return d


def load_meta(job_id):
    with open(os.path.join(job_dir(job_id), "meta.json"), encoding="utf-8") as f:
        m = json.load(f)
    if m.get("user") != current_user():
        abort(404)
    return m


def cleanup():
    cutoff = time.time() - RETENTION_HOURS * 3600
    for name in os.listdir(JOBS):
        p = os.path.join(JOBS, name)
        if os.path.isdir(p) and os.path.getmtime(p) < cutoff:
            for root, _, files in os.walk(p, topdown=False):
                for fn in files:
                    os.remove(os.path.join(root, fn))
                os.rmdir(root)


@app.get("/")
def index():
    current_user()
    return send_from_directory(app.static_folder, "index.html")


@app.post("/api/convert")
def convert():
    user = current_user()
    cleanup()
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify(error="Please choose a file to upload."), 400
    ext = os.path.splitext(f.filename)[1].lower()
    if ext == ".pdf" or ext == ".xls":
        return jsonify(error=f"{ext} files are not supported yet. Please save as .docx or .xlsx and upload again."), 400
    if ext not in ALLOWED:
        return jsonify(error="Only Word (.docx) and Excel (.xlsx) files are supported."), 400

    job_id = uuid.uuid4().hex
    d = job_dir(job_id, create=True)
    src = os.path.join(d, "input" + ext)
    f.save(src)
    base_name = re.sub(r"[^A-Za-z0-9._-]+", "_", os.path.splitext(f.filename)[0])[:60] or "document"
    dst = os.path.join(d, f"Seesec_{base_name}{ext}")

    form = request.form
    cmd = [sys.executable, os.path.join(BASE, "convert.py"), src, dst]
    if ext == ".docx":
        for opt in ("title", "subtitle", "prepared-for", "prepared-by", "version", "date"):
            v = form.get(opt.replace("-", "_"), "").strip()
            if v:
                cmd += [f"--{opt}", v]
        layout = form.get("layout", "report")
        cmd += ["--layout", layout if layout in ("report", "cost") else "report", "--pdf"]
        kpis = [k for k in json.loads(form.get("kpis") or "[]") if k.get("label") or k.get("value")]
        if kpis:
            cmd += ["--kpis", json.dumps(kpis)]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=240)
        out = json.loads(r.stdout.strip().splitlines()[-1]) if r.stdout.strip() else {}
    except Exception:
        out = {}
    if not out.get("ok"):
        msg = out.get("error") or "The document could not be processed. Please check the file and try again."
        _write_meta(d, job_id, user, f.filename, ext, "failed", msg, None, None)
        return jsonify(error=msg, job_id=job_id), 422

    files = {"docx" if ext == ".docx" else "xlsx": os.path.basename(dst)}
    if out.get("pdf"):
        files["pdf"] = os.path.basename(out["pdf"])
    meta = _write_meta(d, job_id, user, f.filename, ext, "done", "", files, out.get("headings_detected"))
    return jsonify(meta)


def _write_meta(d, job_id, user, original, ext, status, error, files, headings):
    meta = {"job_id": job_id, "user": user, "original": original, "ext": ext, "status": status,
            "error": error, "files": files, "headings_detected": headings,
            "created": datetime.now().isoformat(timespec="seconds")}
    with open(os.path.join(d, "meta.json"), "w", encoding="utf-8") as fh:
        json.dump(meta, fh)
    return {k: v for k, v in meta.items() if k != "user"}


@app.get("/api/history")
def history():
    user = current_user()
    items = []
    for name in sorted(os.listdir(JOBS), reverse=True):
        p = os.path.join(JOBS, name, "meta.json")
        if os.path.isfile(p):
            with open(p, encoding="utf-8") as fh:
                m = json.load(fh)
            if m.get("user") == user:
                items.append({k: v for k, v in m.items() if k != "user"})
    items.sort(key=lambda m: m["created"], reverse=True)
    return jsonify(items=items[:30], retention_hours=RETENTION_HOURS)


@app.get("/download/<job_id>/<kind>")
def download(job_id, kind):
    m = load_meta(job_id)
    if kind not in (m.get("files") or {}):
        abort(404)
    return send_file(os.path.join(job_dir(job_id), m["files"][kind]), as_attachment=True)


@app.get("/preview/<job_id>")
def preview(job_id):
    m = load_meta(job_id)
    pdf = (m.get("files") or {}).get("pdf")
    if not pdf:
        abort(404)
    return send_file(os.path.join(job_dir(job_id), pdf), mimetype="application/pdf")


@app.after_request
def headers(r):
    r.headers["X-Content-Type-Options"] = "nosniff"
    r.headers["Cache-Control"] = "no-store"
    return r


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", 5000)))
