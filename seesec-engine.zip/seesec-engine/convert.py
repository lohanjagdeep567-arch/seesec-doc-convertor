#!/usr/bin/env python3
"""CLI the portal calls:  python3 convert.py in.docx out.docx --title ... --prepared-for ...
Prints one JSON line: {"ok": true, "output": "..."} or {"ok": false, "error": "..."}"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def to_pdf(docx_path):
    import subprocess
    outdir = os.path.dirname(os.path.abspath(docx_path))
    r = subprocess.run(["soffice", "--headless", "--convert-to", "pdf", "--outdir", outdir, docx_path],
                       capture_output=True, timeout=180)
    pdf = os.path.splitext(os.path.abspath(docx_path))[0] + ".pdf"
    if r.returncode != 0 or not os.path.exists(pdf):
        raise RuntimeError("PDF export failed (is LibreOffice installed?)")
    return pdf


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("dst")
    ap.add_argument("--title", default="")
    ap.add_argument("--subtitle", default="")
    ap.add_argument("--prepared-by", default="")
    ap.add_argument("--prepared-for", default="")
    ap.add_argument("--version", default="")
    ap.add_argument("--date", default="")
    ap.add_argument("--no-cover", action="store_true")
    ap.add_argument("--layout", choices=["report", "cost"], default="report")
    ap.add_argument("--kpis", default="", help='JSON list: [{"label":"..","value":"..","caption":".."}]')
    ap.add_argument("--pdf", action="store_true", help="also write a PDF next to the output (needs LibreOffice)")
    a = ap.parse_args()

    ext = os.path.splitext(a.src)[1].lower()
    try:
        if ext == ".docx":
            from docx_restyle import restyle_docx
            meta = {"title": a.title, "subtitle": a.subtitle, "prepared_by": a.prepared_by,
                    "prepared_for": a.prepared_for, "version": a.version, "date": a.date}
            info = restyle_docx(a.src, a.dst, meta, cover=not a.no_cover, layout=a.layout,
                                kpis=json.loads(a.kpis) if a.kpis else None)
        elif ext == ".xlsx":
            from xlsx_restyle import restyle_xlsx
            restyle_xlsx(a.src, a.dst)
        elif ext in (".xls", ".pdf"):
            raise ValueError(f"{ext} is not supported yet. Please save as .xlsx / .docx and upload again.")
        else:
            raise ValueError(f"Unsupported file type: {ext}")
    except Exception as e:  # report cleanly to the portal
        print(json.dumps({"ok": False, "error": str(e)}))
        sys.exit(1)
    result = {"ok": True, "output": a.dst}
    if ext == ".docx":
        result["headings_detected"] = info["headings_detected"]
        if a.pdf:
            result["pdf"] = to_pdf(a.dst)
    print(json.dumps(result))


if __name__ == "__main__":
    main()
