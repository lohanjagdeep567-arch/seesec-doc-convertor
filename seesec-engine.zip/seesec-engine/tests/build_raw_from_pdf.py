"""Make a realistic RAW (unformatted) docx from a formatted Seesec PDF:
same words/tables/order, but team-style: Calibri 11, headings = plain bold text,
bullets typed as '- ', tables = plain Table Grid, no colours, no logo."""
import sys, re, pdfplumber
from docx import Document
from docx.shared import Pt

def build(pdf, pages, out, skip_top=60, skip_bottom=740):
    d = Document()
    st = d.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)
    with pdfplumber.open(pdf) as P:
        for pn in pages:
            pg = P.pages[pn-1].crop((0, skip_top if pn>1 else 0, 612, skip_bottom))
            tbls = pg.find_tables()
            items = []
            for t in tbls:
                items.append((t.bbox[1], "table", t.extract()))
            nt = pg.filter(lambda o: not any(t.bbox[0]-1<=o.get("x0",0) and o.get("x1",0)<=t.bbox[2]+1 and t.bbox[1]-1<=o.get("top",0) and o.get("bottom",0)<=t.bbox[3]+1 for t in tbls) if o["object_type"]=="char" else True)
            for line in nt.extract_text_lines():
                chars = line["chars"]
                bold = all("Bold" in c["fontname"] for c in chars if c["text"].strip())
                items.append((line["top"], "line", (line["text"].strip(), bold)))
            items.sort(key=lambda x: x[0])
            buf = []
            def flush():
                if buf: d.add_paragraph(" ".join(buf)); buf.clear()
            for _, kind, v in items:
                if kind == "table":
                    flush()
                    rows = [[(c or "").replace("\n"," ") for c in r] for r in v if any(r)]
                    if not rows: continue
                    t = d.add_table(rows=len(rows), cols=len(rows[0])); t.style = "Table Grid"
                    for i,r in enumerate(rows):
                        for j,c in enumerate(r): t.cell(i,j).text = c
                else:
                    text, bold = v
                    if not text: continue
                    if bold and len(text) < 90:
                        flush(); p = d.add_paragraph(); r = p.add_run(text); r.bold = True
                    elif text.startswith("•"):
                        flush(); d.add_paragraph("- " + text.lstrip("• "))
                    else:
                        buf.append(text)
            flush()
    d.save(out)

if __name__ == "__main__":
    build(sys.argv[1], [int(x) for x in sys.argv[3].split(",")], sys.argv[2])
