from docx import Document
from docx.shared import Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
import openpyxl
d=Document()
d.core_properties.title="Network Security Assessment"
h=d.add_heading("1. Executive Summary",1)
for r in h.runs: r.font.color.rgb=RGBColor(0,0,200); r.font.name="Calibri"
p=d.add_paragraph(); r=p.add_run("Total vulnerabilities found: 42 (High: 7, Medium: 20, Low: 15)."); r.font.name="Times New Roman"; r.font.color.rgb=RGBColor(200,0,0)
d.add_paragraph("First point",style="List Bullet"); d.add_paragraph("Second point",style="List Bullet")
d.add_heading("1.1 Scope",2)
d.add_paragraph("Servers 10.0.0.1 – 10.0.0.50, calculated risk = 7.5 × 0.8 = 6.0")
t=d.add_table(rows=3,cols=3); t.style="Table Grid"
for i,row in enumerate([("Host","Severity","CVSS"),("10.0.0.1","High","8.1"),("10.0.0.2","Low","3.2")]):
    for j,v in enumerate(row):
        c=t.cell(i,j); c.text=v
        tcpr=c._element.get_or_add_tcPr(); sh=OxmlElement("w:shd"); sh.set(qn("w:val"),"clear"); sh.set(qn("w:fill"),"FFFF00" if i==0 else "DDEEFF"); tcpr.append(sh)
d.add_heading("2. Findings",1)
d.add_paragraph("Hyperlink-free paragraph with ₹1,25,000 budget.")
d.save("raw.docx")
wb=openpyxl.Workbook(); ws=wb.active; ws.title="Costs"
ws.append(["Item","Qty","Rate","Total"])
for i,(a,b,c) in enumerate([("Licence",2,1500),("Support",1,800)],start=2):
    ws.append([a,b,c,f"=B{i}*C{i}"])
ws.append(["Grand total",None,None,"=SUM(D2:D3)"])
wb.save("raw.xlsx")
