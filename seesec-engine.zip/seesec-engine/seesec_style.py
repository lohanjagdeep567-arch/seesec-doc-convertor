"""Seesec formatting rules in one place.

Values below were MEASURED from the two approved Seesec reports
(Network Security Assessment - HelpYaar, AWS Cost Optimisation - HelpYaar).
"""
import os

ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")

STYLE = {
    "font": "Arial",
    "text_color": "212121",          # body text (dark grey)
    "muted_color": "555555",         # footer / captions
    "navy": "24456E",                # title, H1, table header fill
    "blue": "3B6EA6",                # H2 / sub-headings
    "title_size_pt": 24,
    "body_size_pt": 10,
    "h1_size_pt": 14,
    "h2_size_pt": 12,
    "h3_size_pt": 10.5,
    "table_size_pt": 9.5,
    "line_spacing": 1.1,
    "page_w_in": 8.5, "page_h_in": 11,   # US Letter
    "margins_in": {"top": 1.0, "bottom": 0.9, "left": 0.7, "right": 0.7},
    "table_header_fill": "24456E",
    "table_header_text": "FFFFFF",
    "table_border_color": "D1D6DE",
    "table_zebra_fill": "F7FAFA",
    "cover_border_color": "B0C4DE",
    "logo": os.path.join(ASSETS, "seesec-header-logo.png"),
    "logo_width_cm": 1.5,
    "cover_logo": os.path.join(ASSETS, "seesec-watermark-clean.png"),
    "cover_logo_width_cm": 6.0,
    "company": "Seesec Infotech Private Limited",
    "footer_brand": "Seesec Infotech",
    # Excel
    "xl_header_fill": "24456E",
    "xl_header_font_color": "FFFFFF",
    "xl_border_color": "D1D6DE",
    "xl_zebra_fill": "F7FAFA",
}
