# Seesec formatting engine (prototype)

python3 convert.py input.docx output.docx --title "..." --prepared-for "..." --version 1.0 --date "13 November 2026"
python3 convert.py input.xlsx output.xlsx

- Needs: python-docx, openpyxl, Pillow.
- All look-and-feel values are in seesec_style.py (edit after checking the approved Seesec reference documents).
- DOCX/XLSX are restyled IN PLACE: original text, tables, images, formulas are kept.
- Not yet done: PDF input, .xls input, faded watermark, portal login, history, web page wiring.

## Options
--layout report   cover page (Network Security report style, default)
--layout cost     AWS cost report style (banner + optional KPI tiles, no cover)
--kpis '[{"label":"Monthly AWS Spend","value":"$66.52","caption":"Current month bill"}]'
--pdf             also produce a PDF (needs LibreOffice installed on the server)
Plain raw files with no Heading styles: "1. Title", "1.1 Title" and short all-bold lines are promoted to headings.

## Web dashboard
pip install -r requirements.txt   (LibreOffice must be installed for PDF output)
python3 app.py                    -> http://localhost:5000
- Upload .docx / .xlsx, choose layout, fill title/client/date (+ KPI tiles for cost layout), Convert.
- Download Word / PDF, preview PDF, history with auto-delete (SEESEC_RETENTION_HOURS, default 24).
- Portal hook: current_user() in app.py - replace with the Seesec Portal login check.
- For production run behind gunicorn + HTTPS, not the Flask dev server.
