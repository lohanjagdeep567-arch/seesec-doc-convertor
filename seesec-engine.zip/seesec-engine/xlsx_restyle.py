"""Restyle an .xlsx in place: values and formulas are never touched, only
fonts, header row, borders, column widths, print setup and header/footer."""
from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

from seesec_style import STYLE


def _used_bounds(ws):
    return ws.min_row, ws.max_row, ws.min_column, ws.max_column


def restyle_xlsx(src, dst):
    wb = load_workbook(src)  # keeps formulas as formulas
    side = Side(style="thin", color=STYLE["xl_border_color"])
    border = Border(left=side, right=side, top=side, bottom=side)
    head_fill = PatternFill("solid", fgColor=STYLE["xl_header_fill"])

    for ws in wb.worksheets:
        if ws.max_row < 1 or ws.max_column < 1:
            continue
        # header row = first non-empty row
        header_row = next(
            (r for r in range(1, min(ws.max_row, 30) + 1)
             if any(c.value not in (None, "") for c in ws[r])), 1)

        widths = {}
        for row in ws.iter_rows(min_row=header_row):
            for c in row:
                if c.value in (None, ""):
                    continue
                is_head = c.row == header_row
                c.font = Font(name=STYLE["font"], size=10,
                              bold=True if is_head else c.font.bold,
                              italic=c.font.italic,
                              color=STYLE["xl_header_font_color"] if is_head else STYLE["text_color"])
                if is_head:
                    c.fill = head_fill
                    c.alignment = Alignment(vertical="center", wrap_text=True,
                                            horizontal=c.alignment.horizontal)
                else:
                    c.alignment = Alignment(vertical="top", wrap_text=True,
                                            horizontal=c.alignment.horizontal)
                    if (c.row - header_row) % 2 == 0:
                        c.fill = PatternFill("solid", fgColor=STYLE["xl_zebra_fill"])
                c.border = border
                n = len(str(c.value)) if not str(c.value).startswith("=") else 12
                widths[c.column_letter] = max(widths.get(c.column_letter, 0), min(n, 60))

        merged_cols = {col for rng in ws.merged_cells.ranges
                       for col in range(rng.min_col, rng.max_col + 1)}
        for letter, w in widths.items():
            from openpyxl.utils import column_index_from_string
            if column_index_from_string(letter) in merged_cols:
                continue
            ws.column_dimensions[letter].width = max(10, w + 3)

        ws.freeze_panes = ws.cell(row=header_row + 1, column=1)
        ws.print_title_rows = f"{header_row}:{header_row}"
        ws.page_setup.orientation = "landscape"
        ws.page_setup.fitToWidth = 1
        ws.page_setup.fitToHeight = 0
        ws.sheet_properties.pageSetUpPr.fitToPage = True
        ws.oddHeader.left.text = STYLE["company"]
        ws.oddHeader.left.font = "Arial,Bold"
        ws.oddHeader.left.size = 9
        ws.oddFooter.right.text = "Page &P of &N"
        ws.oddFooter.right.size = 8
        ws.sheet_properties.tabColor = STYLE["xl_header_fill"]

    wb.properties.creator = STYLE["company"]
    wb.save(dst)
    return dst
