"""Restyle a DOCX in place: the original paragraphs, tables, images and
numbering stay; only fonts, headings, tables, margins, header/footer change."""
import copy
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_TAB_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Inches, Pt, RGBColor

from seesec_style import STYLE


def _rgb(hexstr):
    return RGBColor.from_string(hexstr)


def _set_run_font(run, size_pt=None, bold=None, force_color=True, color=None):
    run.font.name = STYLE["font"]
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.insert(0, rfonts)
    for attr in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
        rfonts.set(qn(attr), STYLE["font"])
    for attr in ("w:asciiTheme", "w:hAnsiTheme", "w:cstheme", "w:eastAsiaTheme"):
        if rfonts.get(qn(attr)) is not None:
            del rfonts.attrib[qn(attr)]
    if size_pt:
        run.font.size = Pt(size_pt)
    if bold is not None:
        run.font.bold = bold
    if force_color and not _inside_hyperlink(run):
        run.font.color.rgb = _rgb(color or STYLE["text_color"])


def _inside_hyperlink(run):
    return run._element.getparent().tag == qn("w:hyperlink")


def _style_named(doc, name):
    try:
        return doc.styles[name]
    except KeyError:
        return None


def _configure_styles(doc):
    normal = doc.styles["Normal"]
    normal.font.name = STYLE["font"]
    normal.font.size = Pt(STYLE["body_size_pt"])
    normal.font.color.rgb = _rgb(STYLE["text_color"])
    normal.paragraph_format.line_spacing = STYLE["line_spacing"]
    normal.paragraph_format.space_after = Pt(6)
    rpr = normal.element.get_or_add_rPr()
    rf = rpr.find(qn("w:rFonts"))
    if rf is None:
        rf = OxmlElement("w:rFonts")
        rpr.insert(0, rf)
    for attr in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
        rf.set(qn(attr), STYLE["font"])

    sizes = {1: STYLE["h1_size_pt"], 2: STYLE["h2_size_pt"], 3: STYLE["h3_size_pt"]}
    for level, size in sizes.items():
        st = _style_named(doc, f"Heading {level}")
        if st is None:
            continue
        st.font.name = STYLE["font"]
        st.font.size = Pt(size)
        st.font.bold = True
        st.font.italic = False
        st.font.color.rgb = _rgb(STYLE["navy"] if level == 1 else STYLE["blue"])
        st.paragraph_format.space_before = Pt(16 if level == 1 else 10)
        st.paragraph_format.space_after = Pt(6)
        st.paragraph_format.keep_with_next = True
        rpr = st.element.get_or_add_rPr()
        rf = rpr.find(qn("w:rFonts"))
        if rf is None:
            rf = OxmlElement("w:rFonts")
            rpr.insert(0, rf)
        for attr in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
            rf.set(qn(attr), STYLE["font"])
        for attr in ("w:asciiTheme", "w:hAnsiTheme", "w:cstheme", "w:eastAsiaTheme"):
            if rf.get(qn(attr)) is not None:
                del rf.attrib[qn(attr)]


def _heading_level(p):
    name = (p.style.name or "") if p.style is not None else ""
    if name.startswith("Heading "):
        try:
            return int(name.split()[1])
        except ValueError:
            return None
    return None


def _restyle_paragraphs(paragraphs, in_table=False):
    for p in paragraphs:
        level = _heading_level(p)
        for run in p.runs:
            if level:
                _set_run_font(run, STYLE[f"h{min(level,3)}_size_pt"], bold=True,
                              color=STYLE["navy"] if level == 1 else STYLE["blue"])
            elif in_table:
                _set_run_font(run, STYLE["table_size_pt"])
            else:
                # keep a run's own size only if it is a deliberate size change
                _set_run_font(run)
        if not level and not in_table and p.runs:
            for run in p.runs:
                if run.font.size is None:
                    run.font.size = Pt(STYLE["body_size_pt"])


def _set_cell_borders(cell, outer_top=None, outer_bottom=None):
    tcpr = cell._element.get_or_add_tcPr()
    old = tcpr.find(qn("w:tcBorders"))
    if old is not None:
        tcpr.remove(old)
    shd = tcpr.find(qn("w:shd"))
    if shd is not None:  # raw documents' colourful shading -> plain white
        tcpr.remove(shd)
    borders = OxmlElement("w:tcBorders")
    inner = STYLE["table_border_color"]
    for edge in ("top", "left", "bottom", "right"):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), "4")
        el.set(qn("w:space"), "0")
        color = inner
        el.set(qn("w:color"), color)
        borders.append(el)
    tcpr.append(borders)


def _set_cell_margins(table, top=60, bottom=60, left=100, right=100):
    tblpr = table._element.tblPr
    old = tblpr.find(qn("w:tblCellMar"))
    if old is not None:
        tblpr.remove(old)
    mar = OxmlElement("w:tblCellMar")
    for k, v in (("top", top), ("left", left), ("bottom", bottom), ("right", right)):
        el = OxmlElement(f"w:{k}")
        el.set(qn("w:w"), str(v))
        el.set(qn("w:type"), "dxa")
        mar.append(el)
    tblpr.append(mar)


def _shade(cell, fill):
    tcpr = cell._element.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill)
    tcpr.append(shd)


def _restyle_table(table):
    _set_cell_margins(table)
    tblw = table._element.tblPr.find(qn("w:tblW"))
    if tblw is None:
        tblw = OxmlElement("w:tblW")
        table._element.tblPr.append(tblw)
    tblw.set(qn("w:type"), "pct")
    tblw.set(qn("w:w"), "5000")
    # table-level borders are replaced by per-cell borders below
    tblpr = table._element.tblPr
    old = tblpr.find(qn("w:tblBorders"))
    if old is not None:
        tblpr.remove(old)
    last = len(table.rows) - 1
    for r_idx, row in enumerate(table.rows):
        if r_idx == 0:
            trpr = row._tr.get_or_add_trPr()
            if trpr.find(qn("w:tblHeader")) is None:
                trpr.append(OxmlElement("w:tblHeader"))
        cant = row._tr.get_or_add_trPr()
        if cant.find(qn("w:cantSplit")) is None:
            cant.append(OxmlElement("w:cantSplit"))
        seen = set()
        for cell in row.cells:
            if id(cell._tc) in seen:  # merged cells repeat
                continue
            seen.add(id(cell._tc))
            _set_cell_borders(cell)
            if r_idx == 0:
                _shade(cell, STYLE["table_header_fill"])
            elif r_idx % 2 == 0:
                _shade(cell, STYLE["table_zebra_fill"])
            for p in cell.paragraphs:
                p.paragraph_format.space_after = Pt(0)
                for run in p.runs:
                    _set_run_font(run, STYLE["table_size_pt"], bold=True if r_idx == 0 else None,
                                  color=STYLE["table_header_text"] if r_idx == 0 else None)
            for nested in cell.tables:
                _restyle_table(nested)


def _add_field(paragraph, instr, size_pt=8):
    def part(build):
        run = paragraph.add_run()
        _set_run_font(run, size_pt, color=STYLE["muted_color"])
        run._element.append(build())
    def fld(kind):
        el = OxmlElement("w:fldChar"); el.set(qn("w:fldCharType"), kind); return el
    def instr_el():
        el = OxmlElement("w:instrText"); el.set(qn("xml:space"), "preserve"); el.text = f" {instr} "; return el
    def text_el():
        el = OxmlElement("w:t"); el.text = "1"; return el
    part(lambda: fld("begin")); part(instr_el); part(lambda: fld("separate")); part(text_el); part(lambda: fld("end"))


def _top_border(paragraph):
    ppr = paragraph._p.get_or_add_pPr()
    pbdr = OxmlElement("w:pBdr")
    top = OxmlElement("w:top")
    top.set(qn("w:val"), "single")
    top.set(qn("w:sz"), "4")
    top.set(qn("w:space"), "6")
    top.set(qn("w:color"), STYLE["table_border_color"])
    pbdr.append(top)
    ppr.append(pbdr)


def _clear(container):
    for p in list(container.paragraphs):
        p._element.getparent().remove(p._element)
    for t in list(container.tables):
        t._element.getparent().remove(t._element)


def _header_footer(section, doc_title=None, client=None, logo=True):
    section.header.is_linked_to_previous = False
    section.footer.is_linked_to_previous = False
    section.different_first_page_header_footer = False
    section.even_page_header_footer = False
    hdr, ftr = section.header, section.footer
    _clear(hdr)
    _clear(ftr)

    hp = hdr.add_paragraph()
    hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    if logo:
        try:
            hp.add_run().add_picture(STYLE["logo"], width=Cm(STYLE["logo_width_cm"]))
        except (FileNotFoundError, OSError):
            r = hp.add_run("SEESEC")
            _set_run_font(r, 9, bold=True, color=STYLE["navy"])

    fp = ftr.add_paragraph()
    _top_border(fp)
    width = section.page_width - section.left_margin - section.right_margin
    fp.paragraph_format.tab_stops.add_tab_stop(width, WD_TAB_ALIGNMENT.RIGHT)
    left = STYLE["footer_brand"]
    if doc_title:
        left += "  |  " + doc_title
    if client:
        left += " \u2014 " + client
    r = fp.add_run(left)
    _set_run_font(r, 8.5, color=STYLE["muted_color"])
    r = fp.add_run("\tPage ")
    _set_run_font(r, 8.5, color=STYLE["muted_color"])
    _add_field(fp, "PAGE", 8.5)
    r = fp.add_run(" of ")
    _set_run_font(r, 8.5, color=STYLE["muted_color"])
    _add_field(fp, "NUMPAGES", 8.5)


def _insert_cover(doc, meta):
    """Add a cover page in front of the original content. Only user-supplied
    metadata is used; nothing is invented."""
    body = doc.element.body
    first = body[0]
    new_elems = []

    def para(text, size, bold, space_before=0, space_after=6, align=WD_ALIGN_PARAGRAPH.CENTER, color=None):
        p = doc.add_paragraph()
        p.alignment = align
        p.paragraph_format.space_before = Pt(space_before)
        p.paragraph_format.space_after = Pt(space_after)
        r = p.add_run(text)
        _set_run_font(r, size, bold=bold, color=color)
        new_elems.append(p._p)
        return p

    para(meta.get("title") or "Document", STYLE["title_size_pt"], True, space_before=40, space_after=8, color=STYLE["navy"])
    if meta.get("subtitle"):
        para(meta["subtitle"], 14, True, space_after=20, color=STYLE["blue"])
    lp = doc.add_paragraph()
    lp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    lp.paragraph_format.space_before = Pt(30)
    lp.paragraph_format.space_after = Pt(40)
    try:
        lp.add_run().add_picture(STYLE["cover_logo"], width=Cm(STYLE["cover_logo_width_cm"]))
    except (FileNotFoundError, OSError):
        pass
    new_elems.append(lp._p)

    rows = [("Prepared by", meta.get("prepared_by") or STYLE["company"])]
    if meta.get("prepared_for"):
        rows.append(("Prepared for", meta["prepared_for"]))
    if meta.get("version"):
        rows.append(("Document version", meta["version"]))
    if meta.get("date"):
        rows.append(("Date", meta["date"]))

    tbl = doc.add_table(rows=len(rows), cols=2)
    for i, (k, v) in enumerate(rows):
        for j, text in enumerate((k, v)):
            cell = tbl.cell(i, j)
            cell.width = Cm(4.5 if j == 0 else 11.5)
            run = cell.paragraphs[0].add_run(text)
            _set_run_font(run, STYLE["body_size_pt"], bold=(j == 0))
            tcpr = cell._element.get_or_add_tcPr()
            b = OxmlElement("w:tcBorders")
            for edge in ("top", "left", "bottom", "right"):
                e = OxmlElement(f"w:{edge}")
                e.set(qn("w:val"), "single")
                e.set(qn("w:sz"), "4")
                e.set(qn("w:color"), STYLE["cover_border_color"])
                b.append(e)
            tcpr.append(b)
    _set_cell_margins(tbl, 100, 100, 140, 140)
    new_elems.append(tbl._tbl)

    br = doc.add_paragraph()
    br.add_run().add_break(WD_BREAK.PAGE)
    new_elems.append(br._p)

    for el in new_elems:
        body.remove(el)
    for el in new_elems:
        first.addprevious(el)


import re

_NUM_H1 = re.compile(r"^\d{1,2}\.\s+\S")
_NUM_H2 = re.compile(r"^\d{1,2}\.\d{1,2}\.?\s+\S")


def _detect_headings(doc):
    """Raw files often have no Heading styles. Only if NONE exist, promote
    obvious headings: '1. Title', '1.1 Title', or short all-bold lines."""
    if any(_heading_level(p) for p in doc.paragraphs):
        return 0
    try:
        h1, h2 = doc.styles["Heading 1"], doc.styles["Heading 2"]
    except KeyError:
        return 0
    n = 0
    for p in doc.paragraphs:
        text = p.text.strip()
        sname = p.style.name if p.style is not None else ""
        if not text or len(text) > 80 or text.endswith((".", ",", ";")) or "List" in sname:
            continue
        if _NUM_H2.match(text):
            p.style = h2
        elif _NUM_H1.match(text):
            p.style = h1
        elif p.runs and all(r.bold for r in p.runs if r.text.strip()) and len(text.split()) <= 12:
            p.style = h2
        else:
            continue
        n += 1
    return n


_TYPED_BULLET = re.compile(r"^\s*[-\u2022\u2013*]\s+(?=\S)")


def _detect_bullets(doc):
    """Lines typed as '- text' / '\u2022 text' become real bullets. Only the
    typed marker is swapped for a real bullet; the words are untouched."""
    try:
        bullet = doc.styles["List Bullet"]
    except KeyError:
        return 0
    n = 0
    for p in doc.paragraphs:
        sname = p.style.name if p.style is not None else ""
        if "List" in sname or not _TYPED_BULLET.match(p.text) or not p.runs:
            continue
        first = next((r for r in p.runs if r.text.strip()), None)
        if first is None or not _TYPED_BULLET.match(first.text):
            continue
        first.text = _TYPED_BULLET.sub("", first.text, count=1)
        p.style = bullet
        n += 1
    return n


def _no_borders(table):
    tblpr = table._element.tblPr
    b = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        e = OxmlElement(f"w:{edge}")
        e.set(qn("w:val"), "nil")
        b.append(e)
    tblpr.append(b)


def _insert_cost_header(doc, meta, kpis):
    """AWS-report style first page: logo, company banner, title, client,
    period line and optional KPI tiles. kpis = [{label,value,caption}]
    supplied by the user - nothing is calculated or invented."""
    body = doc.element.body
    first = body[0]
    els = []

    def para(text, size, bold=False, color=None, align=WD_ALIGN_PARAGRAPH.CENTER, before=0, after=4):
        p = doc.add_paragraph()
        p.alignment = align
        p.paragraph_format.space_before = Pt(before)
        p.paragraph_format.space_after = Pt(after)
        if text:
            _set_run_font(p.add_run(text), size, bold=bold, color=color)
        els.append(p._p)
        return p

    lp = doc.add_paragraph()
    lp.paragraph_format.space_after = Pt(0)
    try:
        lp.add_run().add_picture(STYLE["cover_logo"], width=Cm(2.4))
    except (FileNotFoundError, OSError):
        pass
    els.append(lp._p)
    para(STYLE["company"].upper().replace("PRIVATE LIMITED", "PVT LTD"), 12.5, True, STYLE["navy"], before=0, after=8)
    para((meta.get("title") or "Report").upper(), 16, True, STYLE["navy"], after=2)
    if meta.get("prepared_for"):
        para(meta["prepared_for"], 10.5, True, STYLE["blue"], after=2)
    line = " | ".join(x for x in (meta.get("subtitle"), meta.get("date") and f"Prepared: {meta['date']}") if x)
    if line:
        para(line, 8.5, False, STYLE["muted_color"], after=10)

    if kpis:
        t = doc.add_table(rows=1, cols=len(kpis))
        _no_borders(t)
        for i, k in enumerate(kpis[:4]):
            cell = t.cell(0, i)
            _shade(cell, STYLE["table_zebra_fill"])
            tcpr = cell._element.get_or_add_tcPr()
            b = OxmlElement("w:tcBorders")
            for edge in ("top", "left", "bottom", "right"):
                e = OxmlElement(f"w:{edge}")
                e.set(qn("w:val"), "single"); e.set(qn("w:sz"), "6")
                e.set(qn("w:color"), "FFFFFF")
                b.append(e)
            tcpr.append(b)
            for j, (txt, size, bold, col) in enumerate((
                (k.get("label", ""), 8, True, STYLE["blue"]),
                (k.get("value", ""), 14, True, STYLE["navy"]),
                (k.get("caption", ""), 7.5, False, STYLE["muted_color"]),
            )):
                p = cell.paragraphs[0] if j == 0 else cell.add_paragraph()
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                p.paragraph_format.space_after = Pt(1)
                _set_run_font(p.add_run(txt), size, bold=bold, color=col)
        _set_cell_margins(t, 80, 80, 60, 60)
        els.append(t._tbl)
        sp = doc.add_paragraph()
        sp.paragraph_format.space_after = Pt(6)
        els.append(sp._p)

    for el in els:
        body.remove(el)
    for el in els:
        first.addprevious(el)


def restyle_docx(src, dst, meta=None, cover=True, layout="report", kpis=None):
    meta = meta or {}
    doc = Document(src)
    if not meta.get("title"):
        meta["title"] = (doc.core_properties.title or "").strip()
        if not meta["title"]:
            for p in doc.paragraphs:
                if p.style is not None and p.style.name in ("Title", "Heading 1") and p.text.strip():
                    meta["title"] = p.text.strip()
                    break

    for p in doc.paragraphs:  # breathing room for text right after a table
        prev = p._p.getprevious()
        if prev is not None and prev.tag == qn("w:tbl"):
            p.paragraph_format.space_before = Pt(8)
    detected = _detect_headings(doc)
    _detect_bullets(doc)
    _configure_styles(doc)
    _restyle_paragraphs(doc.paragraphs)
    for t in doc.tables:
        _restyle_table(t)

    m = STYLE["margins_in"]
    for s in doc.sections:
        s.page_width, s.page_height = Inches(STYLE["page_w_in"]), Inches(STYLE["page_h_in"])
        s.top_margin, s.bottom_margin = Inches(m["top"]), Inches(m["bottom"])
        s.left_margin, s.right_margin = Inches(m["left"]), Inches(m["right"])
        _header_footer(s, meta.get("title"), meta.get("prepared_for"), logo=(layout != "cost"))

    if layout == "cost":
        _insert_cost_header(doc, meta, kpis)
    elif cover:
        _insert_cover(doc, meta)

    doc.core_properties.author = STYLE["company"]
    doc.save(dst)
    return {"output": dst, "headings_detected": detected}
